# Server wale client ko deploy kaise karein

Har server-client ke liye 5 step (≈10 min):

1. **Supabase**: client ke Gmail se supabase.com par project banao.
   Settings → API se **Project URL** aur **anon public key** copy karo.
2. **SQL**: Supabase → SQL Editor → `schema.sql` poora paste karke **Run** (sirf ek baar).
3. **config.json**: dist ke andar `config.json` kholo aur bharo:
   ```json
   { "supabaseUrl": "https://xxxx.supabase.co", "supabaseAnonKey": "eyJ..." }
   ```
4. **Hosting**: dist ke andar ki files (dist folder nahi) us client ke GitHub Pages / Cloudflare Pages repo mein upload karo.
   Us URL ka domain license sheet mein authorize karo (pehle jaisa).
5. **Client**: link kholo → license key daalo → Settings → **Server** → **Connect Server** (1 click).

Kisi bhi dusre device / phone par: wahi link + wahi license key => data apne aap aa jata hai.

Bina server wale client: `config.json` khali chhodo (ya dist hi alag do). Unko Server tab dikhega hi nahi.

## Google Sheet update zaroori nahi hai
Server ki URL/key `config.json` se aati hai. Optional: sheet mein `supabase_url`, `supabase_anon_key` columns
add karke Apps Script response mein bhejoge to config.json ke bina bhi chalega.
